﻿function ValidateCOuntry(country) {
   
   
    if (country.length < 4) {
     
        return false;


    }

    return true;
}